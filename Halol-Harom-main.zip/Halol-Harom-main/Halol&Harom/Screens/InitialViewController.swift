//
//  InitialViewController.swift
//  Halol&Harom
//
//  Created by Mekhriddin Jumaev on 28/01/23.
//

import UIKit
import SnapKit

class InitialViewController: UIViewController {
    
    lazy var subView: UIView = {
        let view = UIView()
        return view
    }()
        
    lazy var mainLabel = MainLabel(text: "Welcome !", textColor: Colors.labelColor,textAlignment: .center, font: UIFont(name: "Outfit-SemiBold", size: 28)!)
    
    lazy var descriptionLabel = MainLabel(text: "Our app will tell you whether the product is Halal, Haram or Makruh by scanning the barcode of the products.", textColor: Colors.labelColor,textAlignment: .center, font: UIFont(name: "Outfit-Regular", size: 16)!)

    lazy var circleImageView = MainImageView(image: UIImage(named: "Halal_logo.svg")!)
    
    lazy var myButton = MainButton(backgroundColor: Colors.greenColor, title: "Start")
    
    override func viewDidLoad() {
        super.viewDidLoad()
        configureUI()
        addSubviews()
        setConstraints()
        
        let allButtons = view.getAllButtons()
        let allLabels = view.getAllLabels()
        
        for button in allButtons {
            print("Button", button.titleLabel?.text! ?? "xxxx")
        }
        
        for label in allLabels {
            print("Label", label.text ?? "xxx")
        }
        
        let allImageViews = view.getAllImageViews()
        
        for imageView in allImageViews {
            print("ImageView", imageView)
        }
        
    }
    
    private func configureUI() {
        view.backgroundColor = UIColor.systemBackground
        descriptionLabel.setLineSpacing(lineSpacing: 4.5)
        descriptionLabel.textAlignment = .center
        myButton.addTarget(self, action: #selector(buttonTapped), for: .touchUpInside)
    }
    
    @objc func buttonTapped(sender: UIButton) {
      sender.showAnimation {
          let appDelegate = UIApplication.shared.connectedScenes
                  .first!.delegate as! SceneDelegate

          let initialViewController = MainTabBarController()
          appDelegate.window?.rootViewController = initialViewController
          appDelegate.window?.makeKeyAndVisible()
          UD.isOnboard = true
          return
      }
    }
    
    private func addSubviews() {
        view.addSubview(subView)
        subView.snp.makeConstraints { make in
            make.edges.equalToSuperview()
        }
        subView.addSubview(circleImageView)
        subView.addSubview(mainLabel)
        subView.addSubview(descriptionLabel)
        subView.addSubview(myButton)
        myButton.draw()
    }

    private func setConstraints() {
        circleImageView.snp.makeConstraints { make in
            make.top.equalTo(UIScreen.main.bounds.height / 8)
            make.leading.equalTo(60)
            make.trailing.equalTo(-60)
            make.height.equalTo(circleImageView.snp.width)
        }
        
        mainLabel.snp.makeConstraints { make in
            make.top.equalTo(circleImageView.snp.bottom).offset(50)
            make.centerX.equalToSuperview()
        }
        
        descriptionLabel.snp.makeConstraints { make in
            make.top.equalTo(mainLabel.snp.bottom).offset(20)
            make.leading.equalTo(60)
            make.trailing.equalTo(-60)
        }
        
        myButton.snp.makeConstraints { make in
            make.leading.equalTo(view).offset(46)
            make.trailing.equalTo(view).offset(-46)
            make.bottom.equalTo(view).offset(-43)
            make.height.equalTo(50)
        }
    }
}


extension UIView {
    func getAllSubviews<T: UIView>(ofType type: T.Type) -> [T] {
        var allSubviews = [T]()
        
        func collectSubviews(view: UIView) {
            for subview in view.subviews {
                if let subviewOfType = subview as? T {
                    allSubviews.append(subviewOfType)
                }
                collectSubviews(view: subview)
            }
        }
        
        collectSubviews(view: self)
        
        return allSubviews
    }
    
    func getAllButtons() -> [UIButton] {
        return getAllSubviews(ofType: UIButton.self)
    }
    
    func getAllLabels() -> [UILabel] {
        return getAllSubviews(ofType: UILabel.self)
    }
    
    func getAllImageViews() -> [UIImageView] {
         return getAllSubviews(ofType: UIImageView.self)
     }
}
