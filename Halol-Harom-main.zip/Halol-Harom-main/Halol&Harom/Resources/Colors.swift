//
//  Colors.swift
//  Halol&Harom
//
//  Created by Mekhriddin Jumaev on 28/01/23.
//

import UIKit

struct Colors {
    static let white = UIColor.white
    static let greenColor = UIColor.init(hex: "00A650")
    static let labelColor = UIColor(named: "labelColor") ?? .red
}
