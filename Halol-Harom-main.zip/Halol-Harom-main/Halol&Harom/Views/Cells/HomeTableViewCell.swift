//
//  HomeTableViewCell.swift
//  Halol&Harom
//
//  Created by Mekhriddin Jumaev on 25/02/24.
//

import UIKit

class HomeTableViewCell: UITableViewCell {
    
    lazy var greenView: UIView = {
        let view = UIView()
        view.backgroundColor = .clear
        view.layer.cornerRadius = 15
        view.layer.borderColor = UIColor.init(hex: "#0EA61D").cgColor
        view.layer.borderWidth = 1
        return view
    }()
    
    lazy var greenLabel = MainLabel(text: "HALAL", textColor: UIColor.init(hex: "#0EA61D"),textAlignment: .left, font: UIFont(name: "Outfit-Bold", size: 14)!)
    
    let textA = """
Halal food is food that is permitted by Islamic law. It must meet the following conditions:

- It does not contain anything that is considered unlawful according to Islamic law
- It is made, produced, manufactured, processed, and stored using machinery, equipment, and/or utensils that have been cleaned according to Islamic law (shariah)
- It is free from any component that Muslims are prohibited from eating according to Islamic law
- It contains only ingredients that are completely permissible for ingestion by the Islamic faith and have not come into contact with non-halal food
- It is free of ingredients derived from haram sources
- It is made using utensils and equipment that have not been contaminated with haram substances
"""
    
    lazy var greenDescriptionLabel = MainLabel(text: textA, textColor: UIColor(named: "labelColor")!,textAlignment: .left, font: UIFont(name: "Outfit-Regular", size: 15)!)
    
    lazy var redView: UIView = {
        let view = UIView()
        view.backgroundColor = .clear
        view.layer.cornerRadius = 12
        view.layer.borderColor = UIColor.init(hex: "#CF1A1A").cgColor
        view.layer.borderWidth = 1
        return view
    }()
    
    lazy var redLabel = MainLabel(text: "HARAM", textColor: UIColor.init(hex: "#CF1A1A"),textAlignment: .left, font: UIFont(name: "Outfit-ExtraBold", size: 17)!)
    
    let testB = """
In Islam, "haram" refers to anything that is not permissible according to Islamic law. Haram food contains pork, its by-products, or any other forbidden ingredients.
Here are some examples of forbidden foods:
- Pork, reptiles, amphibians, and insects
- Shellfish, including lobster, oysters, and mussels
- Shrimp and scallops
- Animal products or by-products made from any non-certified animal
- Carrion
- The meat of carnivores
- Animals that died due to illness, injury, stunning, poisoning, or slaughtering not in the name of God

Alcohol is also considered haram, including any food or drink containing ethanol, such as beer, wine, and liquor.

Some food additives are also considered haram, including:
- Glycerol (E422) if obtained from pork or non-Halal certified meat sources
- Emulsifiers (E470 to E483) if obtained from pork or non-Halal certified sources
- Edible Bone Phosphate (E542)
"""
    
    lazy var redDescriptionLabel = MainLabel(text: testB, textColor: UIColor(named: "labelColor")!,textAlignment: .left, font: UIFont(name: "Outfit-Regular", size: 15)!)
    
    lazy var yelView: UIView = {
        let view = UIView()
        view.backgroundColor = .clear
        view.layer.cornerRadius = 15
        view.layer.borderColor = UIColor.init(hex: "#C1B013").cgColor
        view.layer.borderWidth = 1
        return view
    }()
    
    lazy var yelLabel = MainLabel(text: "What is makruh food?", textColor: UIColor.init(hex: "#C1B013"),textAlignment: .left, font: UIFont(name: "Outfit-ExtraBold", size: 17)!)
    
    lazy var yelDescriptionLabel = MainLabel(text: "In Islam, makruh is an Arabic word that means \"discouraged\". It's often used as a category for things that fall between halal and haram. Makruh food is permitted because it's not specifically designated as haram, but it's not clearly beneficial either.", textColor: UIColor(named: "labelColor")!,textAlignment: .left, font: UIFont(name: "Outfit-Regular", size: 15)!)
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        addSubviews()
        setConstraints()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func addSubviews() {
        contentView.addSubview(greenView)
        greenView.addSubview(greenLabel)
        let underlineAttribute = [NSAttributedString.Key.underlineStyle: NSUnderlineStyle.thick.rawValue]
        let underlineAttributedString = NSAttributedString(string: "What is halal food?", attributes: underlineAttribute)
        greenLabel.attributedText = underlineAttributedString
        greenLabel.font = UIFont(name: "Outfit-Bold", size: 14)!
        greenView.addSubview(greenDescriptionLabel)
        greenDescriptionLabel.setLineSpacing(lineSpacing: 3.5)
        
        contentView.addSubview(redView)
        redView.addSubview(redLabel)
        let underlineAttributered = [NSAttributedString.Key.underlineStyle: NSUnderlineStyle.thick.rawValue]
        let underlineAttributedStringred = NSAttributedString(string: "What is haram food?", attributes: underlineAttributered)
        redLabel.attributedText = underlineAttributedStringred
        redLabel.font = UIFont(name: "Outfit-Bold", size: 14)!
        redView.addSubview(redDescriptionLabel)
        redDescriptionLabel.setLineSpacing(lineSpacing: 3.5)
        
        contentView.addSubview(yelView)
        yelView.addSubview(yelLabel)
        let underlineAttributeredyel = [NSAttributedString.Key.underlineStyle: NSUnderlineStyle.thick.rawValue]
        let underlineAttributedStringredyel = NSAttributedString(string: "What is makruh food?", attributes: underlineAttributeredyel)
        yelLabel.attributedText = underlineAttributedStringredyel
        yelLabel.font = UIFont(name: "Outfit-Bold", size: 14)!
        yelView.addSubview(yelDescriptionLabel)
        yelDescriptionLabel.setLineSpacing(lineSpacing: 3.5)
    }
    private func setConstraints() {
        greenView.snp.makeConstraints { make in
            make.top.equalTo(contentView.safeAreaLayoutGuide).offset(16)
            make.leading.equalTo(16)
            make.trailing.equalTo(-16)
        }
        
        greenLabel.snp.makeConstraints { make in
            make.leading.equalTo(greenView).offset(20)
            make.trailing.equalTo(greenView).offset(-20)
            make.top.equalTo(greenView).offset(15)
        }
        
        greenDescriptionLabel.snp.makeConstraints { make in
            make.leading.trailing.equalTo(greenLabel)
            make.top.equalTo(greenLabel.snp.bottom).offset(10)
            make.bottom.equalToSuperview().offset(-20)
        }
        
        redView.snp.makeConstraints { make in
            make.top.equalTo(greenView.snp.bottom).offset(22)
            make.leading.equalTo(16)
            make.trailing.equalTo(-16)
        }

        redLabel.snp.makeConstraints { make in
            make.leading.equalTo(redView).offset(20)
            make.trailing.equalTo(redView).offset(-20)
            make.top.equalTo(redView).offset(15)
        }

        redDescriptionLabel.snp.makeConstraints { make in
            make.leading.trailing.equalTo(redLabel)
            make.top.equalTo(redLabel.snp.bottom).offset(10)
            make.bottom.equalToSuperview().offset(-20)
        }
        
        yelView.snp.makeConstraints { make in
            make.top.equalTo(redView.snp.bottom).offset(22)
            make.leading.equalTo(16)
            make.trailing.equalTo(-16)
            make.bottom.equalToSuperview()
        }

        yelLabel.snp.makeConstraints { make in
            make.leading.equalTo(yelView).offset(20)
            make.trailing.equalTo(yelView).offset(-20)
            make.top.equalTo(yelView).offset(15)
        }

        yelDescriptionLabel.snp.makeConstraints { make in
            make.leading.trailing.equalTo(yelLabel)
            make.top.equalTo(yelLabel.snp.bottom).offset(10)
            make.bottom.equalToSuperview().offset(-20)
        }
    }

}
