# Halol-Harom
Halol Va Harom application

Application which our team "Efficient developers" developed in "Open Data Challenge 2023". 
Developers: 
Mekhriddin Jumaev
Aslonkhuja Khamidov
Khabibullokh Khallokhov
